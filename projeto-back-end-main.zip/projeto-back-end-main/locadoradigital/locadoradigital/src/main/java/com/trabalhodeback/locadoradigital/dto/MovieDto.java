package com.trabalhodeback.locadoradigital.dto;

public record MovieDto(String titulo, String produtora, String genero, Integer anoLançamento, Integer numeroEstoque) {}
