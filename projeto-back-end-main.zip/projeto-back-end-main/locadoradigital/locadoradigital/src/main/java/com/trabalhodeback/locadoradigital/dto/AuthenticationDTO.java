package com.trabalhodeback.locadoradigital.dto;

public record AuthenticationDTO(String email, String password, String nome) {
}
